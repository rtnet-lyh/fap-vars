# -*- coding: utf-8 -*-

import re

from .common._base import BaseCheck


class Check(BaseCheck):
    USE_HOST_CONNECTION = True
    CONNECTION_METHOD = 'paramiko'
    PARAMIKO_PROFILE = 'linux'
    PARAMIKO_REUSE_SESSION = False

    DEFAULT_PROCESS_NAME = 'exTMS'
    DEFAULT_BAD_PROCESS_STATES = 'Z,D,T'
    COMMAND_TIMEOUT = 10

    def _parse_bad_states(self, raw_value):
        return {
            token.strip().upper()
            for token in re.split(r'[,| ]+', str(raw_value or ''))
            if token.strip()
        }

    def _parse_top_rows(self, stdout):
        header = []
        rows = []
        for line in str(stdout or '').splitlines():
            parts = re.split(r'\s+', line.strip())
            if not parts or parts == ['']:
                continue
            if 'PID' in parts and '%CPU' in parts and '%MEM' in parts:
                header = parts
                continue
            if not header or len(parts) < len(header):
                continue

            try:
                row = {
                    'pid': parts[header.index('PID')],
                    'user': parts[header.index('USER')],
                    'state': parts[header.index('S')],
                    'cpu_percent': float(parts[header.index('%CPU')]),
                    'mem_percent': float(parts[header.index('%MEM')]),
                    'command': parts[header.index('COMMAND')],
                }
            except (ValueError, IndexError):
                continue
            rows.append(row)
        return rows

    def run(self):
        process_name = self.get_host_var(key='process_name')
        if not process_name:
            process_name = self.get_threshold_var(
                'process_name', 
                default=self.DEFAULT_PROCESS_NAME, 
                value_type='str'
            ).strip()

        bad_states_raw = self.get_threshold_var(
            'bad_process_states',
            default=self.DEFAULT_BAD_PROCESS_STATES,
            value_type='str',
        )
        bad_states = self._parse_bad_states(bad_states_raw)
        command = 'top -b -n 1 | egrep "PID|%s"' % process_name

        result = self._run_paramiko_commands(
            [{'command': command, 'timeout': self.COMMAND_TIMEOUT}],
            become=True,
            profile='linux',
        )[0]

        stdout = (result.get('stdout') or '').strip()
        stderr = (result.get('stderr') or '').strip()
        if result.get('rc') != 0:
            return self.fail(
                'top 명령 실행 실패',
                message='WEB 프로세스 상태를 확인하지 못했습니다.',
                stdout=stdout,
                stderr=stderr,
            )

        rows = self._parse_top_rows(stdout)
        if not rows:
            return self.fail(
                '프로세스 정보 없음',
                message='top 출력에서 대상 프로세스를 찾지 못했습니다.',
                stdout=stdout,
                stderr=stderr,
            )

        bad_rows = [
            row for row in rows
            if (row['state'] or '').strip().upper()[:1] in bad_states
        ]
        metrics = {
            'process_name': process_name,
            'process_count': len(rows),
            'states': sorted({row['state'] for row in rows}),
            'bad_process_count': len(bad_rows),
            'bad_processes': bad_rows,
            'processes': rows,
        }
        thresholds = {
            'process_name': process_name,
            'bad_process_states': sorted(bad_states),
        }

        if bad_rows:
            return self.warn(
                metrics=metrics,
                thresholds=thresholds,
                reasons='비정상 프로세스 상태가 발견되었습니다.',
                message='WEB 프로세스 상태 경고: 비정상 상태 %s건, 기준 %s' % (
                    len(bad_rows),
                    ','.join(sorted(bad_states)),
                ),
            )

        return self.ok(
            metrics=metrics,
            thresholds=thresholds,
            reasons='대상 프로세스 상태에 Z/D/T 상태가 없습니다.',
            message='WEB 프로세스 상태 정상: %s개 프로세스 상태=%s' % (
                len(rows),
                ','.join(metrics['states']),
            ),
        )


CHECK_CLASS = Check
